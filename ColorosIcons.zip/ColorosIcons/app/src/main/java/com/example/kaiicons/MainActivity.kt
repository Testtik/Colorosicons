package com.example.kaiicons

import android.app.WallpaperManager
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.graphics.drawable.toBitmap
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class MainActivity : AppCompatActivity() {

    private lateinit var ivWallpaper: ImageView
    private lateinit var rgPalette: RadioGroup
    private lateinit var ivPrev1: ImageView
    private lateinit var ivPrev2: ImageView
    private lateinit var ivPrev3: ImageView
    private lateinit var switchForce: Switch

    private var currentWallpaperBitmap: Bitmap? = null
    private var paletteColors = listOf(
        Color.parseColor("#FFFFFF"),
        Color.parseColor("#23262E"),
        Color.parseColor("#322D28"),
        Color.parseColor("#432606"),
        Color.parseColor("#7EA406"),
        Color.parseColor("#C3522C")
    )
    private var selectedBgColor = Color.parseColor("#FFFFFF")
    private var selectedFgColor = Color.parseColor("#1A1A1A")

    private val galleryLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let {
            val stream = contentResolver.openInputStream(it)
            currentWallpaperBitmap = BitmapFactory.decodeStream(stream)
            ivWallpaper.setImageBitmap(currentWallpaperBitmap)
            extractPaletteAndRefresh(currentWallpaperBitmap)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        ivWallpaper = findViewById(R.id.ivWallpaper)
        rgPalette = findViewById(R.id.rgPalette)
        ivPrev1 = findViewById(R.id.ivPrev1)
        ivPrev2 = findViewById(R.id.ivPrev2)
        ivPrev3 = findViewById(R.id.ivPrev3)
        switchForce = findViewById(R.id.switchForceColor)

        findViewById<Button>(R.id.btnWallpaperGallery).setOnClickListener {
            galleryLauncher.launch("image/*")
        }

        findViewById<Button>(R.id.btnWallpaperSys).setOnClickListener {
            loadSystemWallpaper()
        }

        switchForce.setOnCheckedChangeListener { _, _ ->
            updatePreviews()
        }

        findViewById<Button>(R.id.btnCreateMtz).setOnClickListener {
            generateAndExportMtzTheme()
        }

        loadSystemWallpaper()
    }

    private fun loadSystemWallpaper() {
        try {
            val wallpaperManager = WallpaperManager.getInstance(this)
            val drawable = wallpaperManager.drawable
            if (drawable != null) {
                val bitmap = drawable.toBitmap(512, 512, Bitmap.Config.ARGB_8888)
                currentWallpaperBitmap = bitmap
                ivWallpaper.setImageBitmap(bitmap)
                extractPaletteAndRefresh(bitmap)
                return
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        val bmp = Bitmap.createBitmap(512, 512, Bitmap.Config.ARGB_8888)
        bmp.eraseColor(Color.parseColor("#2A2D34"))
        currentWallpaperBitmap = bmp
        ivWallpaper.setImageBitmap(bmp)
        extractPaletteAndRefresh(bmp)
    }

    private fun extractPaletteAndRefresh(bitmap: Bitmap?) {
        if (bitmap == null) return

        val w = bitmap.width
        val h = bitmap.height
        val c1 = bitmap.getPixel(w / 4, h / 4)
        val c2 = bitmap.getPixel(w / 2, h / 2)
        val c3 = bitmap.getPixel((w * 3) / 4, (h * 3) / 4)
        val c4 = bitmap.getPixel(w / 4, (h * 3) / 4)

        paletteColors = listOf(
            Color.parseColor("#F5F7FA"),
            Color.parseColor("#22252C"),
            c1, c2, c3, c4
        )

        rgPalette.removeAllViews()
        paletteColors.forEachIndexed { index, color ->
            val shape = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(color)
                setStroke(4, Color.parseColor("#55FFFFFF"))
            }
            val rb = RadioButton(this).apply {
                text = ""
                buttonDrawable = null
                background = shape
                layoutParams = RadioGroup.LayoutParams(96, 96).apply { setMargins(10, 0, 10, 0) }
                isChecked = (index == 0)
            }
            rb.setOnClickListener {
                selectedBgColor = color
                selectedFgColor = getContrastColor(color)
                updatePreviews()
            }
            rgPalette.addView(rb)
        }

        selectedBgColor = paletteColors[0]
        selectedFgColor = getContrastColor(selectedBgColor)
        updatePreviews()
    }

    private fun getContrastColor(color: Int): Int {
        val r = Color.red(color)
        val g = Color.green(color)
        val b = Color.blue(color)
        val luminance = (0.299 * r + 0.587 * g + 0.114 * b)
        return if (luminance > 130) Color.parseColor("#1A1A1A") else Color.parseColor("#F0F2F5")
    }

    private fun updatePreviews() {
        val sampleBmp1 = createCustomIcon(createSampleLogo(Color.parseColor("#2AABEE")), selectedBgColor, selectedFgColor)
        val sampleBmp2 = createCustomIcon(createSampleLogo(Color.parseColor("#FF0000")), selectedBgColor, selectedFgColor)
        val sampleBmp3 = createCustomIcon(createSampleLogo(Color.parseColor("#25D366")), selectedBgColor, selectedFgColor)
        ivPrev1.setImageBitmap(sampleBmp1)
        ivPrev2.setImageBitmap(sampleBmp2)
        ivPrev3.setImageBitmap(sampleBmp3)
    }

    private fun createSampleLogo(color: Int): Bitmap {
        val b = Bitmap.createBitmap(128, 128, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color }
        c.drawCircle(64f, 64f, 48f, p)
        return b
    }

    private fun createCustomIcon(originalAppIcon: Bitmap?, bgColor: Int, fgColor: Int): Bitmap {
        val size = 192
        val output = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(output)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)

        val rect = RectF(8f, 8f, (size - 8).toFloat(), (size - 8).toFloat())
        val squirclePath = Path().apply {
            addRoundRect(rect, size * 0.26f, size * 0.26f, Path.Direction.CW)
        }

        paint.shader = LinearGradient(
            0f, rect.top, 0f, rect.bottom,
            intArrayOf(bgColor, adjustColorBrightness(bgColor, 0.85f)),
            null, Shader.TileMode.CLAMP
        )
        canvas.drawPath(squirclePath, paint)
        paint.shader = null

        canvas.save()
        canvas.clipPath(squirclePath)

        if (originalAppIcon != null) {
            val targetSize = (size * 0.62f).toInt()
            val scaled = Bitmap.createScaledBitmap(originalAppIcon, targetSize, targetSize, true)
            val left = (size - targetSize) / 2f
            val top = (size - targetSize) / 2f

            val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                colorFilter = PorterDuffColorFilter(Color.argb(40, 0, 0, 0), PorterDuff.Mode.SRC_IN)
                maskFilter = BlurMaskFilter(8f, BlurMaskFilter.Blur.NORMAL)
            }
            canvas.drawBitmap(scaled, left, top + 4f, shadowPaint)

            if (switchForce.isChecked) {
                val monoPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    colorFilter = PorterDuffColorFilter(fgColor, PorterDuff.Mode.SRC_IN)
                }
                canvas.drawBitmap(scaled, left, top, monoPaint)
            } else {
                canvas.drawBitmap(scaled, left, top, null)
            }
        }

        val rimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 3f
            shader = LinearGradient(
                0f, rect.top, 0f, rect.bottom,
                Color.argb(130, 255, 255, 255),
                Color.argb(15, 255, 255, 255),
                Shader.TileMode.CLAMP
            )
        }
        canvas.drawPath(squirclePath, rimPaint)
        canvas.restore()

        return output
    }

    private fun adjustColorBrightness(color: Int, factor: Float): Int {
        val r = (Color.red(color) * factor).coerceIn(0f, 255f).toInt()
        val g = (Color.green(color) * factor).coerceIn(0f, 255f).toInt()
        val b = (Color.blue(color) * factor).coerceIn(0f, 255f).toInt()
        return Color.rgb(r, g, b)
    }

    private fun generateAndExportMtzTheme() {
        Toast.makeText(this, "Создание иконпака...", Toast.LENGTH_SHORT).show()

        Thread {
            try {
                val themeDir = File(cacheDir, "miui_theme_temp")
                if (themeDir.exists()) themeDir.deleteRecursively()
                themeDir.mkdirs()

                File(themeDir, "description.xml").writeText("""
                    <?xml version="1.0" encoding="utf-8"?>
                    <MIUI_THEME>
                        <title>Coloros icons</title>
                        <version>1.0</version>
                        <designer>Coloros icons</designer>
                        <author>User</author>
                        <screenSize>1080x2400</screenSize>
                        <icons_version>2</icons_version>
                    </MIUI_THEME>
                """.trimIndent())

                val iconsFolder = File(themeDir, "com.miui.home/icons")
                iconsFolder.mkdirs()

                val pm = packageManager
                val packages = pm.getInstalledApplications(PackageManager.GET_META_DATA)

                var count = 0
                for (appInfo in packages) {
                    if (pm.getLaunchIntentForPackage(appInfo.packageName) == null) continue
                    try {
                        val appIconDrawable = pm.getApplicationIcon(appInfo.packageName)
                        val appBitmap = appIconDrawable.toBitmap(192, 192, Bitmap.Config.ARGB_8888)

                        val generatedIcon = createCustomIcon(appBitmap, selectedBgColor, selectedFgColor)
                        val iconFile = File(iconsFolder, "${appInfo.packageName}.png")
                        FileOutputStream(iconFile).use { out ->
                            generatedIcon.compress(Bitmap.CompressFormat.PNG, 100, out)
                        }
                        count++
                    } catch (e: Exception) {
                    }
                }

                val tempMtz = File(cacheDir, "ColorosIcons_${System.currentTimeMillis()}.mtz")
                ZipOutputStream(FileOutputStream(tempMtz)).use { zos ->
                    zipRecursive(themeDir, themeDir, zos)
                }

                val fileName = tempMtz.name
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    val values = ContentValues().apply {
                        put(MediaStore.Downloads.DISPLAY_NAME, fileName)
                        put(MediaStore.Downloads.MIME_TYPE, "application/octet-stream")
                        put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                    }
                    val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    uri?.let {
                        contentResolver.openOutputStream(it)?.use { out ->
                            tempMtz.inputStream().use { input -> input.copyTo(out) }
                        }
                    }
                } else {
                    val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                    val destFile = File(downloadsDir, fileName)
                    tempMtz.copyTo(destFile, overwrite = true)
                }

                runOnUiThread {
                    Toast.makeText(this, "Готово! Иконок: $count. Файл $fileName в Загрузках.", Toast.LENGTH_LONG).show()
                }

            } catch (e: Exception) {
                e.printStackTrace()
                runOnUiThread {
                    Toast.makeText(this, "Ошибка: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun zipRecursive(root: File, file: File, zos: ZipOutputStream) {
        if (file.isDirectory) {
            file.listFiles()?.forEach { zipRecursive(root, it, zos) }
        } else {
            val zipPath = root.toURI().relativize(file.toURI()).path
            zos.putNextEntry(ZipEntry(zipPath))
            file.inputStream().use { it.copyTo(zos) }
            zos.closeEntry()
        }
    }
}
